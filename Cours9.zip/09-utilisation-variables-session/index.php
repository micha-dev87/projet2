<?php
   /*
   |-------------------------------------------------------------------------------------|
   | DÉMARRAGE DE LA SESSION
   | Doit être exécutée si des variables de session ont été préalablement initialisée.
   |-------------------------------------------------------------------------------------|
   */
   session_start();
   /*
   |-------------------------------------------------------------------------------------|
   | function format($strPHP)
   |-------------------------------------------------------------------------------------|
   | 1. format($strPHP)                           Style par défaut (sRouge sGras), aucune espace
   | 2. format($strPHP, $strStyle)                Style $strStyle, aucun espace
   | 3. format($strPHP, $strStyle, $intNbEspaces) Style $strStyle, $intNbEspaces espaces
   | 4. format($strPHP, $intNbEspaces)            Style par défaut, $intNbEspaces espaces
   | 5. format($strPHP, $intNbEspaces, $strStyle) Style $strStyle, $intNbEspaces espaces
   |-------------------------------------------------------------------------------------|
   */
   function format($strPHP) {
      $strRetour = "";
      /* Initialisation des valeurs par défaut */
      $strStyle = "sRouge sGras";
      $intNbEspaces = 0;
      /* Récupération du nouveau style et/ou du nombre d'espaces forts, si applicable */
      for ($i=1; $i<func_num_args(); $i++) {
         $param = func_get_arg($i);
         switch (gettype($param)) {
            case "integer" : /* Nombre d'espaces forts */
               $intNbEspaces = $param;
               break;
            case "string" : /* Définition du style */
               $strStyle = $param;
               break;
         }
      }
      /* Ajout des espaces forts, si applicable */
      for ($i=1; $i<=$intNbEspaces; $i++) {
         $strRetour .= "&nbsp;";
      }
      $strRetour .= "<span class=\"$strStyle\">$strPHP</span>";
      return $strRetour;
   }
?>
<!DOCTYPE html>
<html>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <title>Utilisation de variables de session</title>
   <style type="text/css">
      BODY, INPUT { font-family:arial; font-size:16px; }
      .sTitreApplication { font-size:32px; line-height:26px; font-weight:bold; margin-top:0px; }
      .sTitreSection { font-size:24px; line-height:18px; }
      .sDroits { font-size:12px; } 
      .sGras { font-weight:bold; }
      .sNonGras { font-weight:normal; }
      .sRouge { color:red; }
      .sPHP, .sSESSION { font-family:consolas; font-size:18px; }
      .sSESSION { text-decoration:underline; }
      .sItalique { font-style:italic; }
      .sBleu { color:blue; }
   </style>
</head>
<body onload="">
   <form id="frmSaisie" method="get" action="">
      <div id="divEntete">
         <p class="sTitreApplication">
            Utilisation de variables de session<br />
            <span class="sTitreSection">
               <span class="sNonGras">par</span><span class="sRouge"> Ronald Jean-Julien</span>
            </span>
            <input id="btnActualiser" name="btnActualiser" type="button" value="Actualiser"
               style="font-size:12px;vertical-align:3px; color:black; " 
               onclick="window.location = document.location.href;" />
         </p>
      </div>
      
      <div id="divCorps">
<?php
   $sPHP = "<p class=\"sPHP\">";
   echo format("<br />Contenu de \$_SESSION[] après le session_start()<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   /* Affichage de l'ID de la session */
   echo "01. ID de la session en cours est " . format(session_id()) . " et son nom est " . format(session_name()) . ".<br />";

   /* Initialisation d'une variable de session*/
   $_SESSION["NomFamille"] = "Leclerc";
   echo "02. Initialisation de la variable de session " . format("NomFamille", "sItalique") . " à " . format("Leclerc", "sBleu") . "<br />";
   
   echo format("<br />Contenu de \$_SESSION[] après l'initialisation de la variable de session<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   /* Test de la présence de la variable de session */
   if (isset($_SESSION["NomFamille"])) {
      echo "03. Confirmation de la présence de la variable de session " . format("NomFamille", "sItalique") . ".<br />";
   }
   else {
      echo "03. La variable de session " . format("NomFamille", "sItalique") . " n'existe pas... Traitement interrompu.";
      die();
   }
      
   /* Affichage du contenu de la variable de session */
   echo "04. Le contenu de la variable de session " . format("NomFamille", "sItalique") . " est ". format($_SESSION["NomFamille"]) . ".<br />";

   /* Suppression de la variable de session */
   unset($_SESSION["NomFamille"]);
   echo "05. Suppression de la variable de session " . format("NomFamille", "sItalique") . ".<br />";
   if (!isset($_SESSION["NomFamille"])) {
      echo "06. Confirmation de la suppression de la variable de session " . format("NomFamille", "sItalique") . ".<br />";
   }

   echo format("<br />Contenu de \$_SESSION[] après la suppression de la variable de session<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   /* Initialisation de deux nouvelles variables de session */
   $_SESSION["Nom"] = "Legendre";
   $_SESSION["Prenom"] = "Paul";
   echo "07. Création de deux nouvelles variables de session (" . format("Nom", "sItalique") . " et " . format("Prenom", "sItalique") . ")<br />";
   echo "08. Confirmation de la création des variables de session...<br />";
   echo format("Nom : ", "", 4) . format($_SESSION["Nom"], 3) . "<br />";
   echo format("Prénom : ", "", 4) . format($_SESSION["Prenom"]) . "<br />";
   
   echo format("<br />Contenu de \$_SESSION[] après la création de deux variables de session<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   /* Suppression de toutes les variables de session mais pas l'ID de la session */
   session_unset();
   echo "09. Suppression de toutes les variables de session, mais pas de l'ID de session.<br />";
   if (!isset($_SESSION["Nom"]) && !isset($_SESSION["Prenom"])) {
      echo "10. Confirmation de la suppression des deux variables de session créées précédemment.<br />";
      echo format("ID de la session en cours est '", "", 4) . format(session_id()) . "' et son nom est '" . format(session_name()) . "'.<br />";
   }

   echo format("<br />Contenu de \$_SESSION[] après la suppression de toutes les variables de session avec SESSION_UNSET<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   /* Initialisation de quatre nouvelles variables de session */
   $_SESSION["Nom"] = "Laliberté";
   $_SESSION["Prenom"] = "Nicole";
   $_SESSION["Age"] = 32;
   $_SESSION["Employe"] = true;
   echo "11. Création de quatre nouvelles variables de session (" . format("Nom", "sItalique") . ", " . format("Prenom", "sItalique") . ", " . format("Age", "sItalique") . " et " . format("Employe", "sItalique") . ")<br />";
   echo "12. Quatre nouvelles variables de session...<br />";
   echo format("Nom : ", "", 4) . format($_SESSION["Nom"], 3) . " de type " . format(gettype($_SESSION["Nom"]), "sItalique") . "<br />";
   echo format("Prénom : ", "", 4) . format($_SESSION["Prenom"]) . " de type " . format(gettype($_SESSION["Prenom"]), "sItalique") . "<br />";
   echo format("Âge : ", "", 4) . format($_SESSION["Age"], 3) . " de type " . format(gettype($_SESSION["Age"]), "sItalique") . "<br />";
   echo format("Employé? ", "", 4) . format($_SESSION["Employe"] ? "Oui" : "Non", "sBleu sGras") . " (" . format($_SESSION["Employe"]) . ") de type " . format(gettype($_SESSION["Employe"]), "sItalique") . "<br />";
   
   echo format("<br />Contenu de \$_SESSION[] après la création de quatre variables de session<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   /* Suppression de toutes les variables de session, mais pas l'ID (session_unset) */
   session_unset();
   
   echo "13. Suppression de toutes les variables de session, mais pas l'ID de la session<br />";
   if (!isset($_SESSION["Nom"]) && !isset($_SESSION["Prenom"]) && !isset($_SESSION["Age"])) {
      echo "14. Confirmation de la suppression de toutes les variables de session créées précédemment.<br />";
      echo format("ID de la session en cours est '", "", 4) . format(session_id()) . "' et son nom est '" . format(session_name()) . "'.<br />";
   }

   echo format("<br />Contenu de \$_SESSION[] après la suppression de toutes les variables de session avec SESSION_UNSET<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;
   
   $_SESSION["Test"] = "Test";
   echo "15. Création d'une variable de session temporaire<br />";

   echo format("<br />Contenu de \$_SESSION[] après la création d'une variable de session temporaire<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;

   /* Suppression de l'ID (session_destroy), mais pas la variable de session temporaire (cependant, elle ne sera plus présente si on actualise la page)
    * Pour vous en convaincre,...
    * (1) actualiser la page courante - la variable de session Test n'a pas été sauvegardée
    * (2) placer l'instruction ci-dessous en commentaire, puis exécuter de nouveau l'application
    * (3) actualiser la page courante - la variable de session Test est présente
    * (4) n'oublier pas d'activer de nouveau l'instruction ci-dessous ! */
   session_destroy();

   echo "16. Suppression de l'ID de la session, mais pas de la variable de session temporaire<br />";
   if (isset($_SESSION["Test"])) {
      echo "17. Confirmation de la présence de la variable de session temporaire.<br />";
      echo format("ID de la session en cours est '", "", 4) . format(session_id()) . "' et son nom est '" . format(session_name()) . "'.<br />";
   }

   echo format("<br />Contenu de \$_SESSION[] après le SESSION_DESTROY<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;

   /* Termine la session courante (facultatif, mais souhaitable dans certaines situations) */
   session_write_close();
   
   echo format("<br />Contenu de \$_SESSION[] après la terminaison de la session courante<br />", "sSESSION");
   var_dump($_SESSION); echo $sPHP;

   echo "</p>";
?>
      </div>
      
      <div id="divPiedPage">
         <p class="sDroits">
            &copy; Département d'informatique G.-G.
         </p>
      </div>
   </form>
</body>
</html>