
      <div id="divPiedPage">
         <p class="sDroits">
            &copy; Département d'informatique G.-G.
         </p>
      </div>
   </form>
</body>
</html>