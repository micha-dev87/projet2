<?php
   /*
   |-------------------------------------------------------------------------------------|
   | DÉMARRAGE DE LA SESSION
   | Doit être exécutée si des variables de session ont été préalablement initialisée.
   |-------------------------------------------------------------------------------------|
   */
   session_start();
   /*
   |-------------------------------------------------------------------------------------|
   | Fonctions de librairie
   |-------------------------------------------------------------------------------------|
   */
   require_once("fonctions-librairie.php");
   /*
   |-------------------------------------------------------------------------------------|
   | accesPageAffichage()
   | Redirection (version PHP)
   |-------------------------------------------------------------------------------------|
   */
   function accesPageAffichage() {
      header("Location: affiche-nom.php");
      die();
   }
   /*
   |-------------------------------------------------------------------------------------|
   | authentification()
   |-------------------------------------------------------------------------------------|
   */
   function authentification($strIdentifiant, $strMotPasse, &$strNomComplet) {
      $tIdentification = Array();
      $tIdentification[0]["Identifiant"] = "11111"; $tIdentification[0]["MotPasse"] = "123"; $tIdentification[0]["Nom"] = "Beaucage"; $tIdentification[0]["Prenom"] = "Raphaël";
      $tIdentification[1]["Identifiant"] = "22222"; $tIdentification[1]["MotPasse"] = "234"; $tIdentification[1]["Nom"] = "Blais";    $tIdentification[1]["Prenom"] = "Dominic";
      $tIdentification[2]["Identifiant"] = "33333"; $tIdentification[2]["MotPasse"] = "345"; $tIdentification[2]["Nom"] = "Blais";    $tIdentification[2]["Prenom"] = "Hugo";
      $tIdentification[3]["Identifiant"] = "44444"; $tIdentification[3]["MotPasse"] = "456"; $tIdentification[3]["Nom"] = "Côté";     $tIdentification[3]["Prenom"] = "Alexandre";
      $tIdentification[4]["Identifiant"] = "55555"; $tIdentification[4]["MotPasse"] = "567"; $tIdentification[4]["Nom"] = "Gagnon";   $tIdentification[4]["Prenom"] = "Lise";
      $binTrouve = false;
      for ($i = 0; $i < count($tIdentification) && !$binTrouve; $i++) {
         if ($strIdentifiant == $tIdentification[$i]["Identifiant"] && $strMotPasse == $tIdentification[$i]["MotPasse"]) {
            $strNomComplet = $tIdentification[$i]["Prenom"] . " " . $tIdentification[$i]["Nom"];
            $binTrouve = true;
         }
      }
      return $binTrouve;
   }
   /*
   |-------------------------------------------------------------------------------------|
   | Est-ce que l'utilisateur a déjà été authentifié ?
   |-------------------------------------------------------------------------------------|
   */
   if (isset($_SESSION["NomComplet"])) {
      accesPageAffichage();
   }
   /*
   |-------------------------------------------------------------------------------------|
   | Est-ce que l'utilisateur demande à être authentifié ?
   |-------------------------------------------------------------------------------------|
   */
   $strIdentifiant = parametre("tbIdentifiant");
   $strMotPasse = parametre("tbMotPasse");
   $strMessageAuthentification = "";
   
   if ($strIdentifiant != null || $strMotPasse != null) {
      $strNomComplet = null;
      $binAuthentificationConfirmee = authentification($strIdentifiant, $strMotPasse, $strNomComplet);
      if ($binAuthentificationConfirmee) {
         $_SESSION["NomComplet"] = $strNomComplet;
         accesPageAffichage();
      }
      else {
         $strMessageAuthentification = "Identifiant et/ou mot de passe invalide !";
      }
   }
   /*
   |-------------------------------------------------------------------------------------|
   | Variables de travail pour l'en-tête
   |-------------------------------------------------------------------------------------|
   */
   $strTitreApplication = "Démo : Connexion (Validation)";
   $strNomAuteur = "Ronald Jean-Julien";
   
   require_once("en-tete.php");
?>
      <div id="divIdentification" class="">
         <p class="sTitreSection">
            Connectez-vous...
         </p>
         <table>
            <tr>
               <td>Identifiant : </td>
               <td>
                  <input id="tbIdentifiant" name="tbIdentifiant" class="sIdentifiant" type="text" maxlength="5" value="<?php echo $strIdentifiant; ?>" />
               </td>
            </tr>
            <tr>
               <td>Mot de passe : </td>
               <td>
                  <input id="tbMotPasse" name="tbMotPasse" class="sMotPasse" type="text" maxlength="3" />
               </td>
            </tr>
            <tr>
               <td></td>
               <td>
                  <span class="sRouge sGras"><?php echo $strMessageAuthentification; ?></span>
               </td>
            </tr>
            <tr>
               <td></td>
               <td>
                  <input id="btnConfirmer" name="btnConfirmer" class="sBoutonAction" type="submit" value="Connexion" />
               </td>
            </tr>
            
         </table>
      </div>
<?php
   require_once("pied-page.php");
?>