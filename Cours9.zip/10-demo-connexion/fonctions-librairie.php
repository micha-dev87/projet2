<?php   
   /*
   |-------------------------------------------------------------------------------------|
   | parametre (2021-02-11)
   | Récupère le paramètre passé via la barre d'adresse qu'il soit envoyé en GET ou en POST
   | NOUVELLE FONCTION À AJOUTER DANS LA LIBRAIRIE 'librairie-generale-2021-mm-jj.php'
   |-------------------------------------------------------------------------------------|
   */
   function parametre($strIDParam) {
      return filter_input(INPUT_GET, $strIDParam, FILTER_SANITIZE_SPECIAL_CHARS) .
             filter_input(INPUT_POST, $strIDParam, FILTER_SANITIZE_SPECIAL_CHARS);
   }
?>