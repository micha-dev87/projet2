<!DOCTYPE html>
<html>
<head>
   <title><?php echo $strTitreApplication; ?></title>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <style type="text/css">
      BODY { padding-left:15px; padding-top:15px; }
      BODY, INPUT, SELECT { font-family:arial; font-size:16px; }
      TABLE { border-collapse: collapse; }

      .sTitreApplication { font-size:32px; line-height:26px; font-weight:bold; margin-top:0px; }
      .sTitreSection { font-size:24px; line-height:20px; font-weight:bold; }

      .sBoutonAction { background-color:green; color:white; padding:5px; font-weight:bold; }
      .sDroits { font-size:12px; }
      .sGras {font-weight:bold; }
      .sIdentifiant { width:60px; padding:3px; font-weight:bold; }
      .sMotPasse { width:40px; padding:3px; font-weight:bold; }
      .sRouge { color:red; }
   </style>
</head>
<body>
   <form id="frmSaisie" method="get" action="">
      
      <div id="divEntete" class="">
         <p class="sTitreApplication">
            <?php echo "$strTitreApplication\n"; ?>
            <span class="sTitreSection">
               <br />par <span class="sRouge"><?php echo $strNomAuteur; ?></span>
            </span>
         </p>
      </div>
