<?php
   /*
   |-------------------------------------------------------------------------------------|
   | DÉMARRAGE DE LA SESSION
   | Doit être exécutée si des variables de session ont été préalablement initialisée.
   |-------------------------------------------------------------------------------------|
   */
   session_start();
   /*
   |-------------------------------------------------------------------------------------|
   | Fonctions de librairie
   |-------------------------------------------------------------------------------------|
   */
   require_once("fonctions-librairie.php");
   /*
   |-------------------------------------------------------------------------------------|
   | retourPageConnexion()
   | Redirection (version Javascript)
   |-------------------------------------------------------------------------------------|
   */
   function retourPageConnexion() {
?>
      <script type="text/javascript">
         alert('Vous ne pouvez pas accéder à cette page sans vous être connecté !');
         window.location = "index.php";
      </script>
<?php
   }
   /*
   |-------------------------------------------------------------------------------------|
   | Est-ce que l'utilisateur est authentifié ?
   |-------------------------------------------------------------------------------------|
   */
   if (!isset($_SESSION["NomComplet"])) {
      retourPageConnexion();
   }
   /*
   |-------------------------------------------------------------------------------------|
   | Est-ce que l'utilisateur demande de se déconnecter ?
   |-------------------------------------------------------------------------------------|
   */
   $binDeconnecter = parametre("btnDeconnecter");
   if ($binDeconnecter) {
      $_SESSION["NomComplet"] = null;
      header("Location: index.php");
      die();
   }
   /*
   |-------------------------------------------------------------------------------------|
   | Variables de travail pour l'en-tête
   |-------------------------------------------------------------------------------------|
   */
   $strTitreApplication = "Démo : Connexion (Confirmation)";
   $strNomAuteur = "Ronald Jean-Julien";
   
   require_once("en-tete.php");
?>
      <div id="divIdentification" class="">
         <p class="sTitreSection">
            Bienvenue <?php echo $_SESSION["NomComplet"]; ?>
         </p>
         <p>
            <input id="btnDeconnecter" name="btnDeconnecter" class="sBoutonAction" type="submit" value="Déconnecter" />
         </p>
      </div>
<?php
   require_once("pied-page.php");
?>